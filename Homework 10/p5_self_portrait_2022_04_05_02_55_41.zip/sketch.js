var x=120
var x1=275

var y=170
var y1=170

var a=115

var size=20;
var count= 0;
var sizeDirection=2;
function setup() 

{
  createCanvas(400, 400);
}


function draw() {
  background(69, 133, 97);
   

  
  a = Math.floor(Math.random() * 10) + 1; 
  
  
  //head
  noStroke(0);
  fill(254, 220, 210)
  ellipse(195, 195, 300, 370,)
  
  //ears 
  noStroke(0);
  fill(254, 220, 210)
  rect(15, 130, 55, 90, 50);
  rect(325, 130, 55, 90, 50);
   
  //eyes
  stroke(1);
  fill(247, 247, 255);
  ellipse (x, 170, 60);
  ellipse(x1, 170, 60);
  stroke(1);
  fill(16, 59, 26);
  ellipse(120, y, 40);
  ellipse(275, y1, 40);
  stroke(1);
  fill(0, 0, 0);
  ellipse(120, 170, 20);
  ellipse(275, 170, 20);
  
  
  //hat
  fill(66, 63, 60)
  rect(55, 0, 280, 110, 20, 20, 10, 10);
  fill(28, 27, 26)
  rect(55, 55, 280, 55, 10, 10, 10, 10);
  
  //brows
  fill(48, 30, 16)
  rect(60, a, 110, 30, 10)
  rect(220, a, 110, 30, 10)
  
  //nose
  stroke(1)
  fill(254, 214, 208);
  fill(235, 198, 195);
  triangle(170, 225, 220, 225, 195, 270);
  
  //mouth 
  arc(195, 300, 80, 80, 0, PI,CHORD);
  
  if (x >= 400) {
    x *= -1;
  }
  
  x=x+1;
  
  
  if (x1 >= 400) {
    x1 *= -1;
  }
  
  x1=x1+1;  
  
  
  if (y >= 400) {
    y *= -1;
  }
  
  y=y+1;
  
  
  if (y1 >= 400) {
    y1 *= -1;
  }
  
  y1=y1+1; 
  
  
  textSize(size);
  size+= sizeDirection;
  count++;
  if(count > 5)
  {
    sizeDirection *=-1;
    count =0;
  }
  text('Tyler R', 10, 390);
  
}

  
  

  
  
