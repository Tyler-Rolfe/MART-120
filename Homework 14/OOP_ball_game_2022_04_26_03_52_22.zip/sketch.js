class Shape
{
  
  constructor (x, y, w, h, r, g, b)
  {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.r = r;
    this.g = g;
    this.b = b;
  }
  
  display()
  {
    fill (this.r, this.g, this.b)
    square (this.x, this.y, this.w, this.h);
  }
  
}

var x=100;
var y=100;
var x1=275;
var y1=170;

var w=87;
var s=83;
var a=65;
var d=68;

var Square1;
var Square2;
var Square3;

var mouseShapeX;
var mouseShapeY;

function setup() 
{
  createCanvas(400, 400);
  x1= Math.floor(Math.random() * 10) + 1;
  y1= Math.floor(Math.random() * 10) + 1;
  
  Square1 = new Shape(210, 210, 50, 50, 354, 454, 45);
  Square2 = new Shape(40, 250, 50, 50, 123, 45, 46);
  Square3 = new Shape(337, 80, 50, 50, 423, 36,86);
}

function draw() {
  background(99, 99, 99);
  
  fill (148, 0, 89)
  createBorders();
  
  exitText();
  
  enemyCircles();
  
  blueCircle();
  
  exitTextWin();
  
  fill(148, 0, 89);
  circle (mouseShapeX, mouseShapeY, 10);
  
  Square1.display();
  Square2.display();
  Square3.display();
}


  function mouseClicked()

{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;

}
  
function createBorders()
{
  rect(0,0, width, 10);
  rect(0,0,10, width);
  rect(0,width-10, width-100, 10);
  rect(width-10, 0, 10, width-9)
}

function exitText()
{
  textSize(20);
  fill(62, 59, 122)
  text('EXIT', width-80, width-9)
}

function enemyCircles()
{
  fill(148, 0, 89);
  ellipse (x1, 170, 60);
  ellipse(120, y1, 40);
  
  if (x1 >= 400) {
    x1 *= -1;
  }
  
  x1=x1+1; 
  
  
  if (y1 >= 400) {
    y1 *= -1;
  }
  
  y1=y1+1;
}

function blueCircle()
{
  fill(62, 59, 122)
  circle(x, y, 25)
  
  if (keyIsDown(w))
  {
    y -= 5;
  }
  
  if (keyIsDown(s))
  {
    y += 5;
  }
  
  if (keyIsDown(a))
  {
    x -= 5;
  }
  
  if (keyIsDown(d))
  {
    x += 5;
  }
}

function exitTextWin()
{
  if (x > width-80 && y > width-9)
    {
    textSize(50);
    text('You Win!',width/2-80, width/2-9);
    }
}




  
