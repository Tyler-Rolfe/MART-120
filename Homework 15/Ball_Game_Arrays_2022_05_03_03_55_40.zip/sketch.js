var x=100;
var y=100;
var shapeX=50;
var shapeY=50;

var w=87;
var s=83;
var a=65;
var d=68;

var shapeXs = [];
var shapeYs = [];
var diameters = [];

var shapeXSpeeds = [];
var shapeYSpeeds = [];

var mouseShapeX;
var mouseShapeY;

function setup() 
{
  createCanvas(400, 400);
  
 for (var i = 0; i < 5; i++) {
        shapeXSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) - 1);
        shapeYSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) - 1);
        shapeXs[i] = getRandomNumber(300);
        shapeYs[i] = getRandomNumber(300);
        diameters[i] = getRandomNumber(25);
}

    }
  function draw() {
  background(99, 99, 99);
  
  fill (148, 0, 89)
  createBorders();
    
for (var i = 0; i < shapeXs.length; i++) {
        circle(shapeXs[i], shapeYs[i], diameters[i]);
        shapeXSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) - 1);
        shapeYSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) - 1);

        shapeXs[i] += shapeXSpeeds[i];
        shapeYs[i] += shapeYSpeeds[i];
        
        if (shapeXs[i] > 400) {
            shapeXs[i] = 0;
        }
        if (shapeXs[i] < 0) {
            shapeXs[i] = 400;
        }
        if (shapeYs[i] > 400) {
            shapeYs[i] = 0;
        }
        if (shapeYs[i] < 0) {
            shapeYs[i] = 400;
        }
    }
  
  exitText();
  
  blueCircle();
  
  exitTextWin();
  
  fill(148, 0, 89);
  circle (mouseShapeX, mouseShapeY, 25);
}


  function mouseClicked()

{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;

}
  
function createBorders()
{
  rect(0,0, width, 10);
  rect(0,0,10, width);
  rect(0,width-10, width-100, 10);
  rect(width-10, 0, 10, width-9)
}

function exitText()
{
  textSize(20);
  fill(62, 59, 122)
  text('EXIT', width-80, width-9)
}


function blueCircle()
{
  fill(62, 59, 122)
  circle(x, y, 25)
  
  if (keyIsDown(w))
  {
    y -= 5;
  }
  
  if (keyIsDown(s))
  {
    y += 5;
  }
  
  if (keyIsDown(a))
  {
    x -= 5;
  }
  
  if (keyIsDown(d))
  {
    x += 5;
  }
}

function exitTextWin()
{
  if (x > width-80 && y > width-9)
    {
    textSize(50);
    text('You Win!',width/2-80, width/2-9);
    }
}
function getRandomNumber(number) {
    return Math.floor(Math.random() * number) + 10;
}
