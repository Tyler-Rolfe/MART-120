function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(69, 133, 97);
  text('Tyler R', 10, 30);
  
  
  //head
  noStroke(0);
  fill(254, 220, 210)
  ellipse(195, 195, 300, 370,)
  
  
  //eyes
  stroke(1);
  fill(247, 247, 255);
  ellipse(120, 170, 60);
  ellipse(275, 170, 60);
  stroke(1);
  fill(16, 59, 26);
  ellipse(120, 170, 40,);
  ellipse(275, 170, 40);
  stroke(1);
  fill(0, 0, 0);
  ellipse(120, 170, 20);
  ellipse(275, 170, 20);
  
  //ears 
  noStroke(0);
  fill(254, 220, 210)
  rect(15, 130, 55, 90, 50);
  rect(325, 130, 55, 90, 50);
  
  //hat
  fill(66, 63, 60)
  rect(55, 0, 280, 110, 20, 20, 10, 10);
  fill(28, 27, 26)
  rect(55, 55, 280, 55, 10, 10, 10, 10);
  
  //brows
  fill(48, 30, 16)
  rect(60, 115, 110, 30, 10)
  rect(220, 115, 110, 30, 10)
  
  //nose
  stroke(1)
  fill(254, 214, 208);
  fill(235, 198, 195);
  triangle(170, 225, 220, 225, 195, 270);
  
  //mouth 
  arc(195, 300, 80, 80, 0, PI,CHORD);
  
  
  
}